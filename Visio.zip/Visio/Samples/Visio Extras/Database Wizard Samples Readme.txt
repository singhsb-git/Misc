*****************************************
VISIO 2000 DATABASE WIZARD README.TXT FILE
*****************************************

Copyright (c) 1997-1999 Visio Corporation. All rights reserved.

This README.TXT file covers the following topics

	1.  Visio sample database files
	2.  Notes about the Database Wizard
	3.  Notes about the Database Wizard and Excel

***************************************
Section 1 - Visio sample database files
***************************************

The following sample files are shipped as part of the Visio 2000 installations in 
the DATABASE\SAMPLES sub-directory.

	a) DBSAMPLE.MDB 
         - a sample Access 95 database containing tables of data and queries
           which create views and summaries of the data in the tables.

	b) Sample Database Airplane Seating.vsd
         - a sample drawing representing the seating arrangements on an
           airplane.  The drawing is connected to the sample database when
           opened and modifications to the passenger shapes in the drawing 
           are also made in the database.

        c) Sample Database Airplane Seating.vst
         - a template file for creating airplane seating drawings

        d) Sample Database Network Layout.vsd
         - a sample drawing representing the location of computers in an
           office.  The drawing is connected to the sample database when 
           opened and modifications to the computer shapes in the drawing 
           are also made in the database.

        e) Sample Database Office Layout.vsd
         - a sample drawing representing the location of employees in an
           office.  The drawing is connected to the sample database when
           opened and modifications to the employee shapes in the drawing
           are also made in the database.

        f) Sample Database Office Layout.vst
         - a template file for creating office layout drawings

        g) Sample Database Shapes.vsd
         - a sample drawing containing a number of shapes which are linked
           to tables in the sample database.  Use the right mouse actions to
           move information to and from the database.

        g) Sample Database Shapes.vss - some sample shapes
         - a sample stencil containing a number of sample shapes which are
           linked to the tables and queries in the sample database.

*******************************************
Section 2 - Notes about the Database Wizard
*******************************************

The Database Wizard links Visio shapes and drawings to ODBC data
sources. It allows data to be copied to and from Visio shapes and
tables in these data sources. The Database Wizard does not support
the following:

a) ODBC Strings longer than 64K characters to be stored in Visio cells and fields.

b) Database Key fields of the following types:
    
SQL_TIMESTAMP

c) Updating of replication ID's in Access.

d) Updating of Timestamp fields in Informix

e) ODBC Binary fields longer than 32K to be stored in Visio cells and fields.

In addition, the Visio internal storage for numeric values is as double 
floating point numbers and so numbers with a large degree of precision will
be stored as approximate values.

*****************************************************
Section 3 - Notes about the Database Wizard and Excel
*****************************************************

a) The Excel ODBC driver does not support deletion of rows in Excel. As 
a work-around, the Database Wizard marks rows as deleted by setting
text fields to #ROW DELETED# and numeric fields to 0. This means that
0 and #ROW DELETED# are treated as an invalid key for Wizard 
operations such as UPDATE, SELECT, REFRESH, etc.

b) The Database Wizard can create tables in Microsoft Excel files through 
the define table option. Tables created in Excel 5 or later are stored on 
separate sheets in the Excel file and the records are marked as a named 
range. To access an existing table in an Excel file via ODBC you will 
need to create a named range in the Excel file which includes all of the 
rows and columns in the table.  Note: the text in the first row of the 
named range is used as the table column names.

**************************
End of SAMPLES\README.TXT
**************************

